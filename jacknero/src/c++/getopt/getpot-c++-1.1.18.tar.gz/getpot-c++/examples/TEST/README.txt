These unit tests are to be performed with 'hwut'.
See http://hwut.sourceforge.net.
